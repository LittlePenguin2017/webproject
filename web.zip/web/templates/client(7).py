#coding:utf-8
from socket import *
import threading,sys,json,re
import webbrowser
import requests
HOST = '172.20.10.12'  ##
PORT=8101
BUFSIZE = 1024  ##缓冲区大小  1K
ADDR = (HOST, PORT)
myre = r"^[_a-zA-Z]\w{0,}"
tcpCliSock = socket(AF_INET,SOCK_STREAM)
userAccount = None
global p2p
p2p =0
def socket_server(p2pport):
    HOST = '172.20.10.12'  # 本地localhost
    #PORT = 50010
    PORT=p2pport
    print(PORT)
    s = socket(AF_INET, SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen(100)

    conn, addr = s.accept()  # 接受连接
    print(conn)
    print(addr)
    print('连接成功，按下q键后可开始聊天')
    while True:
        data = conn.recv(1024).decode('utf-8')  # 1024个字节
        # 单连接，没有数据断开，服务器断开
        if not data:
            break
        print('接收到：', data)
        msg = input(">>:").strip()
        if len(msg) == 0:
            continue
        # s.sendall('Hello Huangpingyi')
        conn.sendall(msg.encode('utf-8'))
    conn.close()


def socket_client(p2pport):
    HOST = '172.20.10.12'
    #PORT = 50010
    PORT = p2pport
    s = socket(AF_INET, SOCK_STREAM)
    s.connect((HOST, PORT))
    print(HOST)
    print(PORT)
    while True:
        msg = input(">>:").strip()
        if len(msg) == 0:
            continue
        elif msg == "exit":
            break
            # s.sendall('Hello Huangpingyi')
        s.sendall(msg.encode('utf-8'))
        data = s.recv(1024).decode('utf-8')
        print(data)
    s.close()


def register():
    print("""
    欢迎加入!
    """)
    accout = input('Please input your account: ')
    if not re.findall(myre, accout):
        print('账号不合法!')
        return None
    password1  = input('Please input your password: ')
    password2 = input('Please confirm your password: ')
    tag = input('Please input your role(user or manager): ')
    if not (password1 and password1 == password2):
        print('密码不合法!')
        return None
    global userAccount
    userAccount = accout
    regInfo = [accout,password1,'register',tag]
    datastr = json.dumps(regInfo)
    tcpCliSock.send(datastr.encode('utf-8'))
    data = tcpCliSock.recv(BUFSIZE)
    data = data.decode('utf-8')
    if data == '0':
        print('注册成功!')
        return True
    elif data == '1':
        print('注册失败，账号已存在!')
        return False
    else:
        print('异常错误!')
        return False

def login():
    print("""
    欢迎登陆
    """)
    accout = input('账号: ')
    if not re.findall(myre, accout):
        print('账号错误!')
        return None
    password = input('密码: ')
    if not password:
        print('密码错误!')
        return None
    tag = input('角色: ')
    global userAccount
    userAccount = accout
    loginInfo = [accout, password,'login',tag]
    datastr = json.dumps(loginInfo)
    tcpCliSock.send(datastr.encode('utf-8'))
    data = tcpCliSock.recv(BUFSIZE)
    data = data.decode('utf-8')
    if data == '0':
        print('登陆成功!')
        return True
    else:
        print('登陆失败(用户不存在或密码错误)!')
        return False
def addGroup():
    groupname = input('请输入组名: ')
    if not re.findall(myre, groupname):
        print('组名不合法!')
        return None
    return groupname

def chat(target):
    while True:
        print('{} -> {}: '.format(userAccount, target))
        msg = input()
        if len(msg) > 0 and not msg in 'qQ':
            if 'group' in target:
                optype = 'cg'
            else:
                optype = 'cp'

            dataObj = {'type': optype, 'to': target, 'msg': msg, 'froms': userAccount}
            datastr = json.dumps(dataObj)
            tcpCliSock.send(datastr.encode('utf-8'))
            continue
        elif msg in 'qQ':
            break
        else:
            print('所发送消息不合法!')

def p2pchat(target):
        print('{} -> {}: 请指定端口号'.format(userAccount, target))
        global p2p
        p2p = input()
        if len(p2p) > 0 and not p2p in 'qQ':
            if 'group' in target:
                optype = 'cg'
            else:
                optype = 'cp'

            dataObj = {'type': optype, 'to': target, 'msg': p2p, 'froms': userAccount}
            datastr = json.dumps(dataObj)
            tcpCliSock.send(datastr.encode('utf-8'))                         #########
        else:
            print('Send data illegal!')
class inputdata(threading.Thread):
    global p2p
    def run(self):
        menu = """
         _____________________________________________
        |      |                                     |
        |  CP  |               P2P聊天                |
        |______|_____________________________________|
        |      |                                     |
        |  CG  |                群聊                  |
        |______|_____________________________________|
        |      |                                     |
        |  AG  |               创建群组               |
        |______|_____________________________________|
        |      |                                     |
        |  EG  |               加入群组               |
        |______|_____________________________________|
        |      |                                     |
        |  WE  |               打开网页               |
        |______|_____________________________________|
        |      |                                     |
        |  RE  |          获取服务器readme文档         |
        |______|_____________________________________|
        |      |                                     |
        |  H   |               更多帮助               |
        |______|_____________________________________|
        |      |                                     |
        |  Q   |               退出系统               |
        |______|_____________________________________|
                        """
        print(menu)
        while True:
            operation = input('请输入您要进行的操作(按"h"获得帮助): ')
            if operation in 'cPCPCpcp':
                target = input('您想和谁聊天: ')
                p2pchat(target)
                print('client')
                p2pport=int(p2p)
                socket_client(p2pport)
                continue

            if  operation in 'cgCGCgcG':
                target = input('您想和那个群组聊天: ')
                chat('group'+target)
                continue
            if operation in 'agAGAgaG':
                groupName = addGroup()
                if groupName:
                    dataObj = {'type': 'ag', 'groupName': groupName,'name':userAccount}
                    dataObj = json.dumps(dataObj)
                    tcpCliSock.send(dataObj.encode('utf-8'))
                continue

            if operation in 'egEGEgeG':
                groupname = input('请输入您想加入的群组名: ')
                if not re.findall(myre, groupname):
                    print('group name illegal!')
                    return None
                dataObj = {'type': 'eg', 'groupName': 'group'+groupname}
                dataObj = json.dumps(dataObj)
                tcpCliSock.send(dataObj.encode('utf-8'))
                continue
            if operation in 'hH':
                print(menu)
                continue

            if operation in 'WEwe':
                target = input('您想访问的网址: ')
                url2 = target
                webbrowser.open(url2, new=0, autoraise=True)
                webbrowser.open_new(url2)
                webbrowser.open_new_tab(url2)
                continue

            if operation in 'REre':
                import requests
                url = "http://127.0.0.1:8000/readme.html"
                payload = {'message': "hello server"}
                r = requests.post(url, data=payload)
                if r.status_code == 200:
                    print("post请求成功")
                    print(r.status_code)
                    str = r.content
                    str2 = str.decode('utf-8')
                    print(str2)
                continue


            if operation in 'qQ':
                sys.exit(1)

class getdata(threading.Thread):
    def run(self):
        while True:
            data = tcpCliSock.recv(BUFSIZE).decode('utf-8')
            if data == '-1':
                print('无法连接到目标!')
                continue
            if data == 'ag0':
                print('添加组成功!')
                continue

            if data == 'eg0':
                print('进组成功!')
                continue

            if data == 'eg1':
                print('进组失败!')
                continue

            if 'server' in data:
                temmp=data[6:]
                p2pport= int(temmp)
                #print(p2pport)
                socket_server(p2pport)
                continue

            if '登录' in data:            ####################添加
                print(data)

            if len(data) > 10:
                dataObj = json.loads(data)
                if dataObj['type'] == 'cg':
                    print('{}(from {})-> : {}'.format(dataObj['froms'], dataObj['to'], dataObj['msg']))
            else:
                print(data)


def main():

        try:
            tcpCliSock.connect(ADDR)
            print('服务器已连接')
            while True:
                loginorReg = input('L（登录） 或者 R（注册） 账户: ')
                if loginorReg in 'lL':
                    log = login()
                    if log:
                        break
                if loginorReg in 'rR':
                    reg = register()
                    if reg:
                        break

            myinputd = inputdata()
            mygetdata = getdata()
            myinputd.start()
            mygetdata.start()
            myinputd.join()
            mygetdata.join()

        except Exception:
            print('错误')
            tcpCliSock.close()
            sys.exit()


if __name__ == '__main__':
    main()