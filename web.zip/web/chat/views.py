# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import HttpResponse

import socket
import re

from multiprocessing import Process

# 设置静态文件根目录
#HTML_ROOT_DIR = "./html"
HTML_ROOT_DIR ="D:\PYcharmp\PyCharm 2018.1.4\C\web\html"

def handle_client(request):
    return render(request, "readme.html")

def index(request):
    #request.POST
    #request.GET
    return HttpResponse("hello world")
from django.shortcuts import render

# Create your views here.
